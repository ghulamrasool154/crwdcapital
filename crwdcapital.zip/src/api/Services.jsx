import { BsLaptopFill } from "react-icons/bs";

export const Services = [
    {

        id: '1',
        title: 'Online Payment ',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna',
        icon: <BsLaptopFill />
    },
    {

        id: '2',
        title: 'Digital Saving ',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna',
        icon: <i className="fa-solid fa-hand-holding-dollar"></i>
    },
    {

        id: '3',
        title: 'Debit & Credit ',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna',
        icon: <i className="fa-solid fa-credit-card"></i>
    },
    {

        id: '4',
        title: 'Online Investment',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna',
        icon: <i className="fa-solid fa-cart-flatbed"></i>
    },
    {

        id: '5',
        title: 'Pay Bill',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna',
        icon: <i className="fa-solid fa-file-invoice"></i>
    },
    {

        id: '6',
        title: 'Discount & Promo',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna',
        icon: <i className="fa-solid fa-file-invoice"></i>
    }


]

