import img1 from '../assets/images/testimonila1.jpg'
import img2 from '../assets/images/testimonila2.jpg'
import img3 from '../assets/images/testimonilal3.jpg'
import img4 from '../assets/images/testimonilal4.jpg'
export const TestimonialData = [
    {
        id: 1,
        img: img1,
        name: 'John Doe',
        Designation: 'Designation',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.        '
    },
    {
        id: 2,
        img: img2,
        name: 'John Doe',
        Designation: 'Designation',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.        '

    },
    {
        id: 3,
        img: img3,
        name: 'John Doe',
        Designation: 'Designation',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.        '

    },
    {
        id: 4,
        img: img4,
        name: 'John Doe',
        Designation: 'Designation',
        disc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.        '

    },


]


