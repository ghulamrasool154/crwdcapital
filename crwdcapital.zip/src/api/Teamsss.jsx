import team1 from '../assets/images/team1.jpg'
import team2 from '../assets/images/team2.jpg'
import team3 from '../assets/images/team3.jpg'
import team4 from '../assets/images/team4.png'
import team5 from '../assets/images/team5.png'
import team6 from '../assets/images/team6.png'
export const Teamsss = [
    {
        id: 1,
        name: 'Aniya Barlow',
        d: 'HR Manager',
        img: team1
    },
    {
        id: 2,
        name: 'Valent Decker',
        d: 'CEO & Founder',
        img: team2
    },
    {
        id: 3,
        name: 'Alan Alexander',
        d: 'Tax Consultant',
        img: team3
    },
    {
        id: 4,
        name: 'Aniya Barlow',
        d: 'HR Manager',
        img: team4

    },
    {
        id: 5,
        name: 'Valent Decker',
        d: 'CEO & Founder',

        img: team5

    },
    {
        id: 6,
        name: 'Alan Alexander',
        d: 'Tax Consultant',
        img: team6
    }
]

