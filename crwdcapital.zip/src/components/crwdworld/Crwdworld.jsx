import React from 'react'
import Titlebar from '../../abstructComponents/titlebar/Titlebar'


const Crwdworld = () => {
    return (

        <>
            <div>

                <Titlebar span='Crwdworld' title='Our' para='Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.' />
            </div>

        </>)
}

export default Crwdworld